import { medusaVitePlugin, type MedusaVitePlugin } from "./plugin"

export default medusaVitePlugin
export type { MedusaVitePlugin }
