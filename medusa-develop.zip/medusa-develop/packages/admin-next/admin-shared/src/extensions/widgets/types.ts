import { INJECTION_ZONES } from "./constants"

export type InjectionZone = (typeof INJECTION_ZONES)[number]
