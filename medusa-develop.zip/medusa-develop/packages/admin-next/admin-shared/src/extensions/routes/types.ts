import { ROUTE_IMPORTS } from "./constants"

export type RouteImport = (typeof ROUTE_IMPORTS)[number]
