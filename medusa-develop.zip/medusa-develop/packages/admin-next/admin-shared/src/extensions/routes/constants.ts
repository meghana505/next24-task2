export const ROUTE_IMPORTS = ["routes/pages", "routes/links"] as const
