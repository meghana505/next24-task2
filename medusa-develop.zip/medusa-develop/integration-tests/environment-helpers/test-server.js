const { startBootstrapApp } = require("./bootstrap-app")

startBootstrapApp()
