---
"@medusajs/workflows-sdk": patch
---

feat(workflows-sdk): Execute workflows as step in other workflows
