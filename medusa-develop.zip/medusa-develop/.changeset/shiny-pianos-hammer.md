---
"@medusajs/inventory-next": patch
"@medusajs/types": patch
---

Check stock to create reservation and support backorder
