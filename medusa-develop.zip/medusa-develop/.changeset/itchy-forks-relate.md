---
"@medusajs/medusa": patch
---

fix(medusa): Missing middlewares export
