---
"@medusajs/oas-github-ci": patch
---

chore(oas-github-ci): remove v2 option
