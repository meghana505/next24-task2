---
"@medusajs/core-flows": patch
"@medusajs/types": patch
"@medusajs/utils": patch
---

Create stock reservation on complete cart flow
