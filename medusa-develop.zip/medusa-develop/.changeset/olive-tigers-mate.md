---
"@medusajs/medusa-cli": patch
---

feat(medusa-cli): added v2 flag
