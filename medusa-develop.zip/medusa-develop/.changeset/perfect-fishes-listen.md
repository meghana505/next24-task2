---
"@medusajs/notification-sendgrid": patch
"@medusajs/notification-local": patch
"@medusajs/types": patch
---

Add sendgrid and logger notification providers
