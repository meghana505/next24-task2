---
"create-medusa-app": patch
---

fix(create-medusa-app): don't open browser to admin if v2 option is passed
