---
"@medusajs/modules-sdk": minor
"@medusajs/types": minor
"@medusajs/utils": minor
"@medusajs/notification": patch
---

Add basic implementation of a notification module
