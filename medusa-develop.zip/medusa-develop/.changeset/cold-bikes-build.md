---
"@medusajs/medusa-oas-cli": major
---

chore(medusa-oas-cli): remove v2 option + generate v2 OAS by default

## Breaking Change

This introduces a breaking change to the `medusa-oas-cli` as it no longer generates OAS for v1 projects. Users using it with Medusa v1 have to use v0.3.x moving forward.