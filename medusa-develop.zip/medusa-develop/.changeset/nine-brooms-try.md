---
"@medusajs/medusa-oas-cli": patch
"@medusajs/oas-github-ci": patch
---

fix(medusa-oas-cli, oas-github-ci): updated paths to docs directories following monorepo reorganization
