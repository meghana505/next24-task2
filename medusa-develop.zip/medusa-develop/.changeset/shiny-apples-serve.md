---
"@medusajs/fulfillment": patch
---

fix(fulfillment): Update shipping options rules
