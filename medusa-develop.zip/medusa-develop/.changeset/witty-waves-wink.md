---
"@medusajs/link-modules": patch
"@medusajs/fulfillment": patch
"@medusajs/core-flows": patch
"@medusajs/pricing": patch
"@medusajs/utils": patch
"@medusajs/types": patch
---

Fulfillment - shipping options with context
