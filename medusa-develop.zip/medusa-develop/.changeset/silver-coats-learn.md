---
"@medusajs/dashboard": patch
"@medusajs/js-sdk": patch
"@medusajs/types": patch
---

Replace region calls with the SDK in admin, apply typings to sdk
