---
"@medusajs/js-sdk": patch
---

Introduce a js-sdk package for the Medusa API
