---
"@medusajs/fulfillment": patch
"@medusajs/core-flows": patch
---

feat(fulfillment, core-flows): Apply correct address and context + cleanup
