---
"@medusajs/modules-sdk": patch
---

defineLink helper - MedusaApp loading registered links
