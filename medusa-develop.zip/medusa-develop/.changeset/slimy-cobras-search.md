---
"@medusajs/link-modules": patch
"@medusajs/modules-sdk": patch
---

Default MedusaApp schema scalar
