---
"@medusajs/core-flows": patch
"@medusajs/types": patch
"@medusajs/medusa": patch
---

feat(core-flows,types,medusa): API to add promotions to campaign
