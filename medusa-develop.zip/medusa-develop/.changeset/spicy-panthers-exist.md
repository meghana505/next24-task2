---
"@medusajs/core-flows": patch
---

fix(core-flows): set SalesChannels for Products on update
