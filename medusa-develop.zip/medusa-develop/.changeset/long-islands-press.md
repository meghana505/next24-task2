---
"@medusajs/link-modules": patch
"@medusajs/core-flows": patch
"@medusajs/types": patch
"@medusajs/utils": patch
"@medusajs/medusa": patch
---

feat: add Order<>Fulfillment link
