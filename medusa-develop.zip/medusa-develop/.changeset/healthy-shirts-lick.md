---
"@medusajs/promotion": patch
"@medusajs/types": patch
"@medusajs/medusa": patch
---

feat(dashboard,core,medusa,promotion): add campaigns UI
