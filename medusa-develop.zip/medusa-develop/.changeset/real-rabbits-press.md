---
"@medusajs/medusa": patch
"@medusajs/product": patch
"@medusajs/utils": patch
---

fix: Product categories repository and end points

