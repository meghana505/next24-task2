---
"@medusajs/medusa": patch
---

fix(medusa): import and use `RequestQueryFields` from types package
