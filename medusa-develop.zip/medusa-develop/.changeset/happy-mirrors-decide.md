---
"@medusajs/medusa": patch
---

chore(medusa): strict zod versions in workspace
