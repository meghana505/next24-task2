---
"@medusajs/medusa": patch
"@medusajs/link-modules": patch
---

feat(link-module): Order Product link
