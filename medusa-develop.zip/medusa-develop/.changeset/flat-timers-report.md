---
"@medusajs/medusa": patch
---

chore(medusa): cleanup admin function
