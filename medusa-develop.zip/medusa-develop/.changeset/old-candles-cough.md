---
"@medusajs/utils": patch
---

chore(utils): Provide a mikro orm base entity
