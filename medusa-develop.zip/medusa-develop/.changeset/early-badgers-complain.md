---
"@medusajs/medusa": patch
---

fix(medusa): Fix request type in upload route
